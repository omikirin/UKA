#!/usr/bin/env python3
"""素材ライブラリ健診: サイズ極小・インク率異常のセルを洗い出す
usage: python3 health_check.py <poses_dir>"""
import sys,glob,os,io
import cairosvg
from PIL import Image
import numpy as np
d=sys.argv[1]
for f in sorted(glob.glob(d+"/*.svg")):
    sz=os.path.getsize(f)
    flag=[]
    if sz<10000: flag.append(f"極小{sz//1024}KB")
    try:
        png=cairosvg.svg2png(url=f,output_width=200,background_color="white")
        a=np.array(Image.open(io.BytesIO(png)).convert("L"))
        ink=(a<100).mean()
        if ink<0.02: flag.append(f"インク率低{ink:.3f}")
        if ink>0.35: flag.append(f"黒潰れ疑い{ink:.3f}")
    except Exception as e: flag.append("レンダ不能")
    if flag: print(os.path.basename(f), "|", " ".join(flag))
print("健診完了")
