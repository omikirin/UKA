# SVG漫画メーカー キット

小説→ネームJSON→漫画ページを通す、辞書駆動の漫画制作環境です。
このキットは Brain「AIに漫画を『描かせる』のをやめたら、量産できるようになった話」の同梱物です。
詳しい解説・設計思想・トラブル対処は本文をお読みください。

## 同梱物

```
svg-manga-maker/     … Claudeに読み込ませるスキル一式(SKILL.md・辞書・スクリプト)
characters/
  015_uka/poses/     … 宇迦(ウカ) ポーズセル
  015_uka/brain/     … 営業・解説用ポーズ B01〜B10
  006_oto/poses/     … 於兎(オト) ポーズセル
  006_oto/brain/     … 同 B01〜B10
  006_oto/expr/      … オト表情ビートセル45
vectors_expr/        … ウカ表情ビートセル45
vectors_bg/          … 背景100 + Brain専用背景 BGB01〜05
sfx_lib/             … オノマトペ(描き文字)100
tone_kezuri.html     … トーン影エディタ(ブラウザで開くだけ)
sample_name.json     … 最初の1ページ用ネーム(そのまま動きます)
sales_p1.json / sales_p2.json … 営業漫画のネーム(お手本用)
scripts/health_check.py … 素材ライブラリ健診ツール
README.md            … このファイル
```

## 最短セットアップ(15分)

1. **スキルを読み込ませる**
   - Claude Code: `svg-manga-maker/` をスキル置き場(例: `~/.claude/skills/`)へ
   - claude.ai: プロジェクトを作り `svg-manga-maker/` 内のファイルをプロジェクト知識へ
2. **このZIPのルートで作業**。細かいディレクトリ調整はClaudeに「セットアップして」でOK
3. Claudeに **「sample_name.json をレンダして、PNGで見せて」**
4. 出てきたページの台詞やpose_idを1つ変えて、もう一度レンダ

これだけで、画像生成AIを1度も使わずに漫画が1ページ出ます。

## 欠番について(正直な現在地)

以下のセルは抽出品質が基準に満たなかったため、今回のキットからは**欠番として除外**しています
(ネームで指定した場合は「未納品」表示になりますが、ページは止まらず出ます):

- ウカ: P003(全アングル) / P075_back / P075_low / P076_high / P087_back / P087_front / P087_side
- オト: P087_front / P087_high / P087_side

素材は順次更新予定です。自分で素材を追加した際は `scripts/health_check.py <poses_dir>` で健診できます。

## ライセンス・クレジット

キャラクター(宇迦・於兎)はCryptoNinjaの二次創作素材です。
利用の際はCryptoNinja二次創作ガイドラインに従ってください。
